﻿
namespace appgestiopersonnelsoma.vue
{
    partial class responsablegestioper
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewpersonnel = new System.Windows.Forms.DataGridView();
            this.dataGridViewabsence = new System.Windows.Forms.DataGridView();
            this.btnajouterpersonnel = new System.Windows.Forms.Button();
            this.btnmodifierpersonnel = new System.Windows.Forms.Button();
            this.btnsupprimerpersonnel = new System.Windows.Forms.Button();
            this.btnajouterabsence = new System.Windows.Forms.Button();
            this.btnmodifabsence = new System.Windows.Forms.Button();
            this.btnsupprabsence = new System.Windows.Forms.Button();
            this.btnenregistrerpersonnel = new System.Windows.Forms.Button();
            this.btnenregisabsence = new System.Windows.Forms.Button();
            this.btnannulerpersonnel = new System.Windows.Forms.Button();
            this.btnannulerabsence = new System.Windows.Forms.Button();
            this.comboBoxservice = new System.Windows.Forms.ComboBox();
            this.comboBoxmotif = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxnompers = new System.Windows.Forms.TextBox();
            this.textBoxprenompers = new System.Windows.Forms.TextBox();
            this.textBoxmailpers = new System.Windows.Forms.TextBox();
            this.textBoxtelpers = new System.Windows.Forms.TextBox();
            this.textBoxdatedeb = new System.Windows.Forms.TextBox();
            this.textBoxdatefin = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewpersonnel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewabsence)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewpersonnel
            // 
            this.dataGridViewpersonnel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewpersonnel.Location = new System.Drawing.Point(141, 36);
            this.dataGridViewpersonnel.Name = "dataGridViewpersonnel";
            this.dataGridViewpersonnel.RowHeadersWidth = 51;
            this.dataGridViewpersonnel.RowTemplate.Height = 24;
            this.dataGridViewpersonnel.Size = new System.Drawing.Size(1048, 177);
            this.dataGridViewpersonnel.TabIndex = 0;
            // 
            // dataGridViewabsence
            // 
            this.dataGridViewabsence.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewabsence.Location = new System.Drawing.Point(141, 400);
            this.dataGridViewabsence.Name = "dataGridViewabsence";
            this.dataGridViewabsence.RowHeadersWidth = 51;
            this.dataGridViewabsence.RowTemplate.Height = 24;
            this.dataGridViewabsence.Size = new System.Drawing.Size(1048, 181);
            this.dataGridViewabsence.TabIndex = 1;
            // 
            // btnajouterpersonnel
            // 
            this.btnajouterpersonnel.Location = new System.Drawing.Point(12, 36);
            this.btnajouterpersonnel.Name = "btnajouterpersonnel";
            this.btnajouterpersonnel.Size = new System.Drawing.Size(104, 38);
            this.btnajouterpersonnel.TabIndex = 2;
            this.btnajouterpersonnel.Text = "ajouter";
            this.btnajouterpersonnel.UseVisualStyleBackColor = true;
            this.btnajouterpersonnel.Click += new System.EventHandler(this.btnajouterpersonnel_Click);
            // 
            // btnmodifierpersonnel
            // 
            this.btnmodifierpersonnel.Location = new System.Drawing.Point(12, 108);
            this.btnmodifierpersonnel.Name = "btnmodifierpersonnel";
            this.btnmodifierpersonnel.Size = new System.Drawing.Size(104, 38);
            this.btnmodifierpersonnel.TabIndex = 3;
            this.btnmodifierpersonnel.Text = "modifier";
            this.btnmodifierpersonnel.UseVisualStyleBackColor = true;
            this.btnmodifierpersonnel.Click += new System.EventHandler(this.btnmodifierpersonnel_Click);
            // 
            // btnsupprimerpersonnel
            // 
            this.btnsupprimerpersonnel.Location = new System.Drawing.Point(12, 175);
            this.btnsupprimerpersonnel.Name = "btnsupprimerpersonnel";
            this.btnsupprimerpersonnel.Size = new System.Drawing.Size(104, 38);
            this.btnsupprimerpersonnel.TabIndex = 4;
            this.btnsupprimerpersonnel.Text = "supprimer";
            this.btnsupprimerpersonnel.UseVisualStyleBackColor = true;
            this.btnsupprimerpersonnel.Click += new System.EventHandler(this.btnsupprimerpersonnel_Click);
            // 
            // btnajouterabsence
            // 
            this.btnajouterabsence.Location = new System.Drawing.Point(12, 400);
            this.btnajouterabsence.Name = "btnajouterabsence";
            this.btnajouterabsence.Size = new System.Drawing.Size(104, 38);
            this.btnajouterabsence.TabIndex = 5;
            this.btnajouterabsence.Text = "ajouter";
            this.btnajouterabsence.UseVisualStyleBackColor = true;
            // 
            // btnmodifabsence
            // 
            this.btnmodifabsence.Location = new System.Drawing.Point(12, 477);
            this.btnmodifabsence.Name = "btnmodifabsence";
            this.btnmodifabsence.Size = new System.Drawing.Size(104, 38);
            this.btnmodifabsence.TabIndex = 6;
            this.btnmodifabsence.Text = "modifier";
            this.btnmodifabsence.UseVisualStyleBackColor = true;
            this.btnmodifabsence.Click += new System.EventHandler(this.btnmodifabsence_Click);
            // 
            // btnsupprabsence
            // 
            this.btnsupprabsence.Location = new System.Drawing.Point(12, 543);
            this.btnsupprabsence.Name = "btnsupprabsence";
            this.btnsupprabsence.Size = new System.Drawing.Size(104, 38);
            this.btnsupprabsence.TabIndex = 7;
            this.btnsupprabsence.Text = "supprimer";
            this.btnsupprabsence.UseVisualStyleBackColor = true;
            this.btnsupprabsence.Click += new System.EventHandler(this.btnsupprabsence_Click);
            // 
            // btnenregistrerpersonnel
            // 
            this.btnenregistrerpersonnel.Location = new System.Drawing.Point(141, 342);
            this.btnenregistrerpersonnel.Name = "btnenregistrerpersonnel";
            this.btnenregistrerpersonnel.Size = new System.Drawing.Size(104, 38);
            this.btnenregistrerpersonnel.TabIndex = 8;
            this.btnenregistrerpersonnel.Text = "enregistrer";
            this.btnenregistrerpersonnel.UseVisualStyleBackColor = true;
            this.btnenregistrerpersonnel.Click += new System.EventHandler(this.btnenregistrerpersonnel_Click);
            // 
            // btnenregisabsence
            // 
            this.btnenregisabsence.Location = new System.Drawing.Point(141, 709);
            this.btnenregisabsence.Name = "btnenregisabsence";
            this.btnenregisabsence.Size = new System.Drawing.Size(104, 38);
            this.btnenregisabsence.TabIndex = 9;
            this.btnenregisabsence.Text = "enregistrer";
            this.btnenregisabsence.UseVisualStyleBackColor = true;
            this.btnenregisabsence.Click += new System.EventHandler(this.btnenregisabsence_Click);
            // 
            // btnannulerpersonnel
            // 
            this.btnannulerpersonnel.Location = new System.Drawing.Point(264, 342);
            this.btnannulerpersonnel.Name = "btnannulerpersonnel";
            this.btnannulerpersonnel.Size = new System.Drawing.Size(104, 38);
            this.btnannulerpersonnel.TabIndex = 10;
            this.btnannulerpersonnel.Text = "annuler";
            this.btnannulerpersonnel.UseVisualStyleBackColor = true;
            this.btnannulerpersonnel.Click += new System.EventHandler(this.btnannulerpersonnel_Click);
            // 
            // btnannulerabsence
            // 
            this.btnannulerabsence.Location = new System.Drawing.Point(264, 709);
            this.btnannulerabsence.Name = "btnannulerabsence";
            this.btnannulerabsence.Size = new System.Drawing.Size(104, 38);
            this.btnannulerabsence.TabIndex = 11;
            this.btnannulerabsence.Text = "annuler";
            this.btnannulerabsence.UseVisualStyleBackColor = true;
            this.btnannulerabsence.Click += new System.EventHandler(this.btnannulerabsence_Click);
            // 
            // comboBoxservice
            // 
            this.comboBoxservice.FormattingEnabled = true;
            this.comboBoxservice.Location = new System.Drawing.Point(934, 278);
            this.comboBoxservice.Name = "comboBoxservice";
            this.comboBoxservice.Size = new System.Drawing.Size(255, 24);
            this.comboBoxservice.TabIndex = 12;
            // 
            // comboBoxmotif
            // 
            this.comboBoxmotif.FormattingEnabled = true;
            this.comboBoxmotif.Location = new System.Drawing.Point(613, 671);
            this.comboBoxmotif.Name = "comboBoxmotif";
            this.comboBoxmotif.Size = new System.Drawing.Size(255, 24);
            this.comboBoxmotif.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(138, 251);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 17);
            this.label1.TabIndex = 14;
            this.label1.Text = "nom";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(482, 258);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 17);
            this.label2.TabIndex = 15;
            this.label2.Text = "mail";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(129, 302);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 17);
            this.label3.TabIndex = 16;
            this.label3.Text = "prenom";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(482, 307);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 17);
            this.label4.TabIndex = 17;
            this.label4.Text = "tel";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(141, 627);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 17);
            this.label5.TabIndex = 18;
            this.label5.Text = "date debut";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(797, 632);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 17);
            this.label6.TabIndex = 19;
            this.label6.Text = "date fin";
            // 
            // textBoxnompers
            // 
            this.textBoxnompers.Location = new System.Drawing.Point(223, 253);
            this.textBoxnompers.Name = "textBoxnompers";
            this.textBoxnompers.Size = new System.Drawing.Size(225, 22);
            this.textBoxnompers.TabIndex = 20;
            // 
            // textBoxprenompers
            // 
            this.textBoxprenompers.Location = new System.Drawing.Point(223, 302);
            this.textBoxprenompers.Name = "textBoxprenompers";
            this.textBoxprenompers.Size = new System.Drawing.Size(225, 22);
            this.textBoxprenompers.TabIndex = 21;
            // 
            // textBoxmailpers
            // 
            this.textBoxmailpers.Location = new System.Drawing.Point(563, 255);
            this.textBoxmailpers.Name = "textBoxmailpers";
            this.textBoxmailpers.Size = new System.Drawing.Size(225, 22);
            this.textBoxmailpers.TabIndex = 22;
            // 
            // textBoxtelpers
            // 
            this.textBoxtelpers.Location = new System.Drawing.Point(563, 300);
            this.textBoxtelpers.Name = "textBoxtelpers";
            this.textBoxtelpers.Size = new System.Drawing.Size(225, 22);
            this.textBoxtelpers.TabIndex = 23;
            // 
            // textBoxdatedeb
            // 
            this.textBoxdatedeb.Location = new System.Drawing.Point(254, 620);
            this.textBoxdatedeb.Name = "textBoxdatedeb";
            this.textBoxdatedeb.Size = new System.Drawing.Size(294, 22);
            this.textBoxdatedeb.TabIndex = 24;
            // 
            // textBoxdatefin
            // 
            this.textBoxdatefin.Location = new System.Drawing.Point(893, 627);
            this.textBoxdatefin.Name = "textBoxdatefin";
            this.textBoxdatefin.Size = new System.Drawing.Size(286, 22);
            this.textBoxdatefin.TabIndex = 25;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(844, 285);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 17);
            this.label7.TabIndex = 26;
            this.label7.Text = "service";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(549, 678);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 17);
            this.label8.TabIndex = 27;
            this.label8.Text = "motif";
            // 
            // responsablegestioper
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::appgestiopersonnelsoma.Properties.Resources.gestiopersoma2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1215, 759);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBoxdatefin);
            this.Controls.Add(this.textBoxdatedeb);
            this.Controls.Add(this.textBoxtelpers);
            this.Controls.Add(this.textBoxmailpers);
            this.Controls.Add(this.textBoxprenompers);
            this.Controls.Add(this.textBoxnompers);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxmotif);
            this.Controls.Add(this.comboBoxservice);
            this.Controls.Add(this.btnannulerabsence);
            this.Controls.Add(this.btnannulerpersonnel);
            this.Controls.Add(this.btnenregisabsence);
            this.Controls.Add(this.btnenregistrerpersonnel);
            this.Controls.Add(this.btnsupprabsence);
            this.Controls.Add(this.btnmodifabsence);
            this.Controls.Add(this.btnajouterabsence);
            this.Controls.Add(this.btnsupprimerpersonnel);
            this.Controls.Add(this.btnmodifierpersonnel);
            this.Controls.Add(this.btnajouterpersonnel);
            this.Controls.Add(this.dataGridViewabsence);
            this.Controls.Add(this.dataGridViewpersonnel);
            this.Name = "responsablegestioper";
            this.Text = "responsablegestioper";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewpersonnel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewabsence)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewpersonnel;
        private System.Windows.Forms.DataGridView dataGridViewabsence;
        private System.Windows.Forms.Button btnajouterpersonnel;
        private System.Windows.Forms.Button btnmodifierpersonnel;
        private System.Windows.Forms.Button btnsupprimerpersonnel;
        private System.Windows.Forms.Button btnajouterabsence;
        private System.Windows.Forms.Button btnmodifabsence;
        private System.Windows.Forms.Button btnsupprabsence;
        private System.Windows.Forms.Button btnenregistrerpersonnel;
        private System.Windows.Forms.Button btnenregisabsence;
        private System.Windows.Forms.Button btnannulerpersonnel;
        private System.Windows.Forms.Button btnannulerabsence;
        private System.Windows.Forms.ComboBox comboBoxservice;
        private System.Windows.Forms.ComboBox comboBoxmotif;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxnompers;
        private System.Windows.Forms.TextBox textBoxprenompers;
        private System.Windows.Forms.TextBox textBoxmailpers;
        private System.Windows.Forms.TextBox textBoxtelpers;
        private System.Windows.Forms.TextBox textBoxdatedeb;
        private System.Windows.Forms.TextBox textBoxdatefin;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}